<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <div id="f1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>HELPING HANDS</title>
</head>
    <link rel="STYLESHEET" href="home_n.css">
        <div id="bg">
            <body>
                <br><br><br><br>
                    <div id='p'>
                                    <p id="p">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                      The students of RGUKT have taken much responsibility on their shoulders for a noble cause. Their budding thoughts lead them to establish a foundation
                                      <b style="color:red;text-shadow: 0px 0px 10px #F30;">"Helping Hands"</b>for the welfare of the poor students in <i><strong style="color:red;text-shadow: 0px 0px 10px  red;">
                                       AP IIIT'S </strong></i> as well as the 
                                      society.  Tremendous efforts of the innocent dazzling mindsuplifted their spirits and proved themselves that they are the towering inspiration for the
                                      forthcoming generations through their noble contribution to the people who are at the edge of the poverty line.Every journey starts with a single step.
                                      They recognized the value of the first step and took the first step of initiation to show the strength of a rupee.
                                    </p></div>  
    
                                <div id='p'>   

                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Its main motive is to empower the rural poor and to construct a new world to let out their grievances from their 		    lives. Of course they are the tiny tots of the society but their blossoming thoughts ignite the poor and disabled hearts.  It mainly focuses on:</p></div>
     
                                <div id='p'>  

                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	
                                    Helping the poor students, for their daily needs, for travelling expenses, distribution of tricycles for physically challenged students, meeting the    expenses of washing clothes for the disabled and for the medical expenses.

                                </div>  
    
                                <br><br><br>

                                            </p>

                                            </div>
</div>
</div>

</body>
</html>