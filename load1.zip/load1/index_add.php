<html>
<head>
	
	<script language="javascript" type="text/javascript">
  function resizeIframe(obj) {
    obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
  }
</script>

</head>
	<body>
<center>
<iframe width="940" name="Stack" src="./load1/add.php" frameborder="0" scrolling="no" id="iframe" onload='javascript:resizeIframe(this);' />
        </center>
	</body>
</html>
