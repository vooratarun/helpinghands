<html>
<head>
<title>Finance</title>
<style type="text/css">
@font-face{
font-family:Adobe Gothic Std;
src:url('/1copy/load/css/fonts/AdobeGothicStd-Bold.otf');
}
@font-face{
font-family:andlso;
src:url('/1copy/css/fonts/andlso.ttf');
}
h4{
font-size:30px;
color:#903;
margin-left:10px;
font-family:Adobe Gothic Std;
text-align:center;
}
h5{
font-size:20px;
color:#0080C0;
margin-left:10px;
font-family:Adobe Gothic Std;
}
p{
font-size:19px;
color:#000000;
font-family:andalus;
letter-spacing:0.5px;
}
.sign{
border:0px solid brown;
padding:10px 10px 10px 10px;
}
ol li{
color:#000000;
font-size:19px;
font-style:none;
margin-left:30px;
margin-right:50px;
text-align:justify;
font-family:andalus;
}
h5{
color:#0080C0;
font-size:19px;
font-weight:bold;
}
</style>
</head>
<body>
<div id="f1">
<h4 align='center'><b>Money Issuing</b></h4><br>
<center>
    <img src="./images/money.png" width="682"style="width:600px;height;300px;">
</center>
<p> &nbsp;&nbsp;&nbsp;&nbsp;Money reached from various sources like collection from the students, selling of used rough books, collection from the drop box per year, out of 100 %
collection 90% money will be utilized for various activities remaining 10% money will be keep as a treasurer and will utilize at the time of most emergency only. Utilization of 90% money is the following manner:<br>
<h5>Medical charges 30%</h5>
<ol>
<li>Preference is given only for the IIIT Nuzvid campus students. In this regard maximum 1/10th of total medical allocation will be provide per student, during serious case maximum limit will be change according to severity of case and it will be decide by only EC meeting.
</li>
<li>Necessary proofs have to produce for utilizing the medical allowance. (i.e. Medical report/prescription given by M.S/M.D/highly educated Doctors).
</li><br>
<li>Medical allowance sanctioned students should have to produce bills during or after the treatment and one Xerox copy of certificate and bill need to submit to committee.</li><br>
<li>Sanction money if more than 1000 Rs. then transaction should be in check form only.
</li><br>
<li>When money sanctioned then one Xerox of issued check should be submit to committee with back side issued and receiver sign.
</li><br>
<li>Students, who are suffering with "long term diseases", have to renewal every academic year and separate file will be maintain for them and grant will be sanction maximum of  4 years only</li><br>
</ol>
<h5>Daily Needs 30%</h5>
<ol>
<li>Preference is given only for the IIIT Nuzvid campus students..</li><br>
<li>Student need to have at least three HRC recommendations from their departments or domes during the forms.</li><br>
<li>Need to submit the proof of income.</li><br>
<li>Need to submit the Ration Card Xerox.</li><br>
<li>Student need to apply through I Need Help, that is the link provided in our website. Students can approach directly the E.C. if in case of emergency.</li><br>
<li>Verification will be done by the respective HCR and two more HCRs of neighbor classes along with their batch representative.</li><br>
<li>The case should be approved by anyone of the faculty in Accounts department and Chairman along with any two students of E.C.</li><br>
</li><br>Note: For any other transactions, that particular case should get approval from E.C. with two third majority.<br>
</ol>
</div>	
</body>
</html>
