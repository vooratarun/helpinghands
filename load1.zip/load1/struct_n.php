<html>

    <style type="text/css">
    @font-face{
    font-family:Adobe Gothic Std;
    src:url('/1copy/load/css/fonts/AdobeGothicStd-Bold.otf');
    }
    @font-face{
    font-family:andlso;
    src:url('/1copy/css/fonts/andlso.ttf');
}</style>
    <title>HH : Structure</title>
	<style>
            #s1{
                padding: 4em;
                text-align: justify;
}
		#p{
			font-family:andlso;
			position: relative;	
			width:1200px;
			text-align:justify;		
			height:auto;
			background-color:#ffffff;
			color:black;
			font-size:16px;
                        margin: 10em;
			}
			h2{
				text-align:center;				
				color:#0080C0;
				font-size:24px;
				font-family:Adobe Gothic Std;
				}
				p{
					font-size:19px;
                                        font-family:andlso;
					}
				h4{
					color:#0080C0;
					font-family:Adobe Gothic Std;
					font-weight:bold;
					font-size:20px;
					text-align:left;
					}
			ol li{
				font-size:18px;
				margin-left:100px;
				}
	
	</style>
	</head>
        <body>
    <table align="center"><tr><td>
	<div id="s1">
	  <h2 align="center"><strong>STRUCTURE OF ORGANIZATION</strong></h2>
	  <p>
		  There are 4 levels in the Organization of HELPING HANDS
	  <ol>
			<li>Advisory Committee</li>
			<li>Executive Committee</li>
			
			<li>Representative System</li>
			<li>Volunteer System</li>
			</ol>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			For the deatils of the members of above committee please visit "People" tab in menu bar.
			</p>
			<p>&nbsp;</p>
							<h2><u>The Structure of HELPING HANDS</u></h2>
	  <center>
			<img src="./images/heirarchy.png" style="width:550px;height:450px;margin-top:5px;">

      </center>

            
	  <h2 style="font-style:underline;">&nbsp;</h2>
	  <h2 style="font-style:underline;"><u>Functioning of Organization</u></h2>
<h4>1.Money Collection</h4>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				Money collection is through draw boxes.
				The draw boxes are positioned at academic blocks of 
				each batch (For PUC they are placed at each cluster and 
				for Engineering batches they placed at academic blocks).
				Students can contribute money through these draw boxes. 
				Money is taken and count in the presence of working committee and deposited in the SBH account. The details will be displayed in the website.
      </p>
              
	  <h4>2.Gathering the Problems through Representatives</h4>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            	Students those who have problems can mention through enrolling in the website.
				Working committee will gather all the enrollments posted in a defined period.
				If there is any emergency they can directly consult the representatives or working committee members. 
			</p>
	  <h4>3.Executive Committee decisions</h4>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Working committee meets twice in a month. 
			The members will make discussion on the enrolled problems and if the problem is 
			genuine it will be served with proper contribution. The decision will be taken if 
			the 2/3rd majority of WC supports the problem or any proposal. WC decides the amount of 
			money will be debit from the account and distributed to each problem based on the decision.
</p>
	  <h4>4.Contribution</h4>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The amount of money will be served to a particular problem based on the working committee decision. </p>
<br></br>
	</div>
        </tr></td></table>
        </body>
</html>