<?php
?>
<html>
<div id="f1">
<head>
	<title>Rules & Regulations</title>
</head>
 <link rel="STYLESHEET" href="home_n.css">

<div id='h2'>Rules & Regulations</div>
<hr style="width:800px;height:3px;">
<br>

<div id="p2">
1.Every student / faculty must enroll as volunteer, if they want to serve through  RGUKT HELPING HANDS organisation.<br><br>
2.Every volunteer / representative must have one year experience in this organisation.<br><br>
3.Every volunteer / representative  have to renewal for next year if he/she want to be in this organisation for the next year.	(Every renewal is subjected to his candidature during last year.)<br><br>
4.Every decision(any policy or money matters or any proposals) in helping hand organisation must be agreed by 2/3 of people in the E.C. Committee.<br><br>
5.Every batch representative should pass the scrutinizing test by the faculty members in E.C to be a member in E.C.<br><br>
6.If any student punished under disciplinary grounds, he is not eligible for helping hand organisation.<br><br>
</div>
     
<div id="h2">Discipline Measurements</div>
<hr style="width:800px;height:3px;">
<br>
<div id="p2">
Helping Hands would like adopt its own discipline measurements. The member working in the Helping Hands should maintain discipline not only in the organization but <br><br> also in the self discipline. The member's act/behavior which spoils the dignity of the Helping Hands treated as undisciplinary thing and he/she should be suspended <br><br>immediately from Helping Hands Organization.<br><br></div><br><br>

<div id="p">
The following are the some of the undisciplinary things which come under the discipline measurements and have been classified into different clauses. </div>
     

<div id="p">
<ul>Clause-I: Money oriented issues</ul>
</div>

<div id="p2">

<li>The money thefting of helping hands</li>
<li>Encouraging the ineligible persons for their personal benefits for getting money.</li>
<li>Providing wrong information and proofs in getting the money from helping hands (Ex: medical bills, travelling charges...etc)</li>
<li>Unauthorized collection of money without the notice of executive committee.</li>

</div>

     
<div id="p">
<ul>Clause-II:  Behavior oriented issues</ul>
</div>

<div id="p2">
<li>Violations of rules framed for the smooth running of helping hands. </li>
<li>Maintaining the unhealthy interactions/relations using the name of helping hands.</li>
<li>Arguing or scolding one another without the notice of executive committee.</li>
<li>Behaving in the way of commanding/demanding the subordinate members which hurts the ego of others.</li>
<li>Spreading the bad rumors about the helping hands.</li>
<li>Showing the laziness or inactiveness at the work place.</li>
<li>nything which demotivates the other members of helping hands.</li>
</div>     

<div id="p">
<ul>Clause-III: Regularity and other issues</ul>
</div>

<div id="p2">
<li>Absenting the meetings or activities conducted by helping hands without prior notice and proper reason.  </li>
<li>Failing to bring to the notice of EC about the needy people without any reason even after their request to him.</li>
</div>
     
<div id="p">
<ul>Clause-IV: Penalties for the members falling under above issues</ul>
</div>

<div id="p2">
<li>The person falling under any Clause should be suspended immediately.</li>
<li>Subjected to the severity of the situation, he/she should be sent to the discipline committee of our campus.</li>
<li>In case of money thefting or misusing, along with above two actions, money also should be recovered from the person</li>
</div>    
<br><br> 
</div>
 
</html>
